import boto3
import os
import tempfile
import psycopg2
import openpyxl
import pandas as pd
import math

region = 'eu-central-1'
bucket_name = 'thinking-bucket'

db_config = {
    "host": "prod-database.ctaqgooomz1t.eu-central-1.rds.amazonaws.com",
    "port": "5432",
    "database": "postgres",
    "user": "postgres",
    "password": "Pa$$w0rdTk",
}


def process_data_from_xlsx_file(bucket_name):
    s3 = boto3.client('s3')
    sql_content = ""  # Variable to store the SQL commands

    files = get_all_xlsx_files_from_bucket(bucket_name)
    for file in files:
        try:
            obj = s3.get_object(Bucket=bucket_name, Key=file)
            df = pd.read_excel(obj['Body'])

            # Insert data into topics table (avoid duplicates)
            inserted_topics = set()
            for index, row in df.iterrows():
                if not pd.notna(row.iloc[1]):
                    continue
                try:
                    topic_id = int(str(row.iloc[1])[0])  # Assuming the second column (index 1) is question_id
                    if topic_id not in inserted_topics:
                        topic_name = 'math' if topic_id == 1 else 'common knowledge'
                        sql_content += f"INSERT INTO topics (topic_id, topic_name) VALUES ({topic_id}, '{topic_name}') ON CONFLICT (topic_id) DO NOTHING;\n"
                        inserted_topics.add(topic_id)
                except Exception as e:
                    print(e)

            # Insert data into questions and answer_options tables
            for index, row in df.iterrows():
                if not pd.notna(row.iloc[1]):
                    continue
                question_id = str(int(row.iloc[1]))  # Assuming the second column (index 1) is question_id
                language_id = 1
                topic_id = int(str(row.iloc[1])[0])
                c_grade_id = int(question_id[2])  # Set c_grade_id to the last digit of question_id
                level = int(question_id[-1])

                q_top = 2 if topic_id == 3 else 3
                question_text = str(row.iloc[q_top]).replace("'", "`")
                if topic_id == 1:
                    explanation = str(row.iloc[8]).replace("'", "`")
                    interesting_fact = ''
                else:
                    explanation = ""
                    interesting_fact = str(row.iloc[7]).replace("'", "`")

                sql_content += f"""
INSERT INTO questions (question_id, language_id, topic_id, c_grade_id, level, question_text, explanation, interesting_fact)
VALUES ('{question_id}', {language_id}, {topic_id}, {c_grade_id}, {level}, '{question_text}', '{explanation}', '{interesting_fact}') ON CONFLICT (question_id) DO UPDATE SET language_id = {language_id} ,topic_id= {topic_id},c_grade_id ={c_grade_id},level={level},question_text='{question_text}',explanation='{explanation}',interesting_fact='{interesting_fact}';
    """

                q_id = 3 if topic_id == 3 else 4
                correct_answer = str(row.iloc[q_id]).replace("'",
                                                             "`")  # Assuming the fourth column (index 3) is right_answer
                sql_content += f"""
INSERT INTO answer_options (question_id, correct_answer, answer_text)
VALUES ('{question_id}', TRUE, '{correct_answer}');
    """

                q_id = 4 if topic_id == 3 else 5
                wrong_answers = [str(row.iloc[q_id]).replace("'", "`"), str(row.iloc[q_id + 1]).replace("'", "`"),
                                 str(row.iloc[q_id + 2]).replace("'",
                                                                 "`")]  # Assuming columns 5, 6, and 7 are wrong answers
                for i, answer in enumerate(wrong_answers):
                    sql_content += f"""
INSERT INTO answer_options (question_id, correct_answer, answer_text)
VALUES ('{question_id}', FALSE, '{answer}');
    """

        except Exception as e:
            print(f"Error processing file {file}: {e}")

    return sql_content


def get_all_xlsx_files_from_bucket(bucket_name):
    s3 = boto3.client('s3')
    response = s3.list_objects_v2(Bucket=bucket_name)
    files = [obj['Key'] for obj in response.get('Contents', []) if obj['Key'].endswith('.xlsx')]
    return files


def execute_postgresql_code(postgresql_code):
    try:
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute(postgresql_code)
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Error executing PostgreSQL code: {e}")
        raise e


def lambda_handler(event, context):
    try:
        sql_commands = process_data_from_xlsx_file(bucket_name)
        execute_sql(sql_commands, db_config)

        return {
            'statusCode': 200,
            'body': 'Process completed successfully'
        }

    except Exception as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': 'Error processing files'
        }
